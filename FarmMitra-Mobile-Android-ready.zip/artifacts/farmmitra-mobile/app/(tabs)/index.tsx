import { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';

export default function TabOneScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [hindi, setHindi] = useState(true);
  const [photo, setPhoto] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const [checked, setChecked] = useState(false);
  const [alerts, setAlerts] = useState(false);

  const copy = hindi
    ? {
        greeting: 'सुप्रभात, आज फसल को और बेहतर बनाएं',
        subtitle: 'आपकी फसल के लिए सही अगला कदम।',
        upload: 'फसल की फोटो लें',
        sample: 'फोटो चुनें',
        checking: 'फसल की जांच हो रही है…',
        ready: 'आपकी फसल जांच तैयार है',
        issue: 'पत्तियों पर शुरुआती दाग दिख रहे हैं',
        advice: 'सुबह पानी दें और पत्तियों को गीला न रखें। 3 दिन बाद फिर फोटो लेकर तुलना करें।',
        prices: 'आज के मंडी भाव',
        alert: 'मंडी भाव अलर्ट',
        alertOn: 'अलर्ट चालू है',
        language: 'हिंदी',
      }
    : {
        greeting: 'Good morning, let’s grow better today',
        subtitle: 'A clear next step for your crop.',
        upload: 'Take a crop photo',
        sample: 'Choose a photo',
        checking: 'Checking your crop…',
        ready: 'Your crop check is ready',
        issue: 'Early leaf spots may be showing',
        advice: 'Water in the morning and keep leaves dry. Take another photo in 3 days to compare.',
        prices: 'Today’s mandi prices',
        alert: 'Mandi price alerts',
        alertOn: 'Alerts are on',
        language: 'English',
      };

  const pickPhoto = async () => {
    await Haptics.selectionAsync();
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.8,
      allowsEditing: true,
    });
    if (!result.canceled && result.assets[0]?.uri) {
      setPhoto(result.assets[0].uri);
      setChecked(false);
    }
  };

  const takePhoto = async () => {
    await Haptics.selectionAsync();
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (!permission.granted) {
      Alert.alert(
        hindi ? 'कैमरा की अनुमति चाहिए' : 'Camera permission needed',
        hindi ? 'फोटो लेने के लिए कैमरा की अनुमति दें।' : 'Allow camera access to take a crop photo.',
      );
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ['images'],
      quality: 0.8,
      allowsEditing: true,
    });
    if (!result.canceled && result.assets[0]?.uri) {
      setPhoto(result.assets[0].uri);
      setChecked(false);
    }
  };

  const runCheck = () => {
    setChecking(true);
    setTimeout(() => {
      setChecking(false);
      setChecked(true);
    }, 1200);
  };

  return (
    <ScrollView
      style={[styles.screen, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingTop: insets.top + 18, paddingBottom: insets.bottom + 30 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <View style={styles.brandRow}>
          <Image source={require('@/assets/images/icon.png')} style={styles.logo} />
          <View>
            <Text style={[styles.brand, { color: colors.foreground }]}>FarmMitra</Text>
            <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>YOUR FIELD COMPANION</Text>
          </View>
        </View>
        <Pressable
          accessibilityRole="button"
          onPress={() => setHindi((value) => !value)}
          style={[styles.language, { backgroundColor: colors.accent }]}
        >
          <Text style={[styles.languageText, { color: colors.foreground }]}>{copy.language}</Text>
          <Feather name="globe" size={15} color={colors.foreground} />
        </Pressable>
      </View>

      <View style={[styles.hero, { backgroundColor: colors.secondary }]}>
        <View style={styles.statusRow}>
          <View style={[styles.dot, { backgroundColor: colors.primary }]} />
          <Text style={[styles.status, { color: colors.mutedForeground }]}>
            {hindi ? 'आज का खेत साथी' : 'Your field companion, today'}
          </Text>
        </View>
        <Text style={[styles.heroTitle, { color: colors.foreground }]}>{copy.greeting}</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{copy.subtitle}</Text>
      </View>

      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.cardTop}>
          <View>
            <Text style={[styles.cardKicker, { color: colors.primary }]}>01 · CROP CHECK</Text>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>{hindi ? 'फसल में क्या हो रहा है?' : 'Show me what is happening'}</Text>
          </View>
          <View style={[styles.iconCircle, { backgroundColor: colors.accent }]}>
            <Feather name="maximize" size={20} color={colors.foreground} />
          </View>
        </View>
        {photo ? (
          <View>
            <Image source={{ uri: photo }} style={styles.photo} />
            <Pressable onPress={runCheck} style={[styles.primaryButton, { backgroundColor: colors.primary }]}>
              {checking ? <ActivityIndicator color="#fffdf8" /> : <><Feather name="activity" size={18} color="#fffdf8" /><Text style={styles.primaryButtonText}>{hindi ? 'फसल की जांच करें' : 'Check this crop'}</Text></>}
            </Pressable>
          </View>
        ) : (
          <View style={[styles.uploadBox, { borderColor: colors.border, backgroundColor: colors.background }]}>
            <View style={[styles.uploadIcon, { backgroundColor: colors.secondary }]}>
              <Feather name="camera" size={24} color={colors.foreground} />
            </View>
            <Text style={[styles.uploadTitle, { color: colors.foreground }]}>{copy.upload}</Text>
            <Text style={[styles.uploadHint, { color: colors.mutedForeground }]}>JPG, PNG · daylight works best</Text>
            <View style={styles.buttonRow}>
              <Pressable onPress={takePhoto} style={[styles.primaryButton, { backgroundColor: colors.primary }]}>
                <Feather name="camera" size={17} color="#fffdf8" />
                <Text style={styles.primaryButtonText}>{copy.upload}</Text>
              </Pressable>
              <Pressable onPress={pickPhoto} style={[styles.secondaryButton, { borderColor: colors.border }]}>
                <Feather name="image" size={17} color={colors.foreground} />
                <Text style={[styles.secondaryButtonText, { color: colors.foreground }]}>{copy.sample}</Text>
              </Pressable>
            </View>
          </View>
        )}
      </View>

      {checked && (
        <View style={[styles.resultCard, { backgroundColor: colors.foreground }]}>
          <Text style={styles.resultKicker}>{copy.ready}</Text>
          <Text style={styles.resultTitle}>{copy.issue}</Text>
          <Text style={styles.resultBody}>{copy.advice}</Text>
          <View style={styles.resultNote}><Feather name="shield" size={16} color="#e9c75a" /><Text style={styles.resultNoteText}>{hindi ? 'यह शुरुआती संकेत है, अंतिम diagnosis नहीं।' : 'This is an early signal, not a final diagnosis.'}</Text></View>
        </View>
      )}

      <View style={styles.sectionHeading}>
        <View><Text style={[styles.cardKicker, { color: colors.primary }]}>02 · MARKET WATCH</Text><Text style={[styles.sectionTitle, { color: colors.foreground }]}>{copy.prices}</Text></View>
        <Feather name="trending-up" size={22} color={colors.primary} />
      </View>
      <View style={[styles.priceCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View><Text style={[styles.cropName, { color: colors.foreground }]}>Tomato · Nashik</Text><Text style={[styles.priceLabel, { color: colors.mutedForeground }]}>Today’s modal price</Text></View>
        <View style={styles.priceRight}><Text style={[styles.price, { color: colors.foreground }]}>₹2,840</Text><Text style={styles.up}>+8.4%</Text></View>
      </View>
      <Pressable
        accessibilityRole="switch"
        accessibilityState={{ checked: alerts }}
        onPress={() => { setAlerts((value) => !value); Haptics.selectionAsync(); }}
        style={[styles.alertCard, { backgroundColor: alerts ? colors.accent : colors.secondary }]}
      >
        <View style={[styles.alertIcon, { backgroundColor: colors.card }]}><Feather name="bell" size={18} color={colors.foreground} /></View>
        <View style={styles.alertCopy}><Text style={[styles.alertTitle, { color: colors.foreground }]}>{alerts ? copy.alertOn : copy.alert}</Text><Text style={[styles.alertSub, { color: colors.mutedForeground }]}>{hindi ? 'आपके बाजार में बदलाव पर सूचित करेंगे' : 'We’ll notify you when your market moves'}</Text></View>
        <Feather name={alerts ? 'check-circle' : 'chevron-right'} size={20} color={colors.foreground} />
      </Pressable>
      <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>{hindi ? 'FarmMitra की सलाह स्थानीय मौसम और खेत की स्थिति के साथ समझकर इस्तेमाल करें।' : 'Use FarmMitra guidance alongside local weather and field conditions.'}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { paddingHorizontal: 20, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 },
  brandRow: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  logo: { width: 36, height: 36, borderRadius: 11 },
  brand: { fontSize: 21, fontWeight: '700', letterSpacing: -0.7 },
  eyebrow: { fontSize: 8, fontWeight: '700', letterSpacing: 1.1, marginTop: 1 },
  language: { borderRadius: 20, paddingHorizontal: 11, paddingVertical: 8, flexDirection: 'row', gap: 6, alignItems: 'center' },
  languageText: { fontSize: 12, fontWeight: '700' },
  hero: { marginHorizontal: 16, borderRadius: 24, padding: 20, paddingTop: 18, minHeight: 208, justifyContent: 'flex-end', marginBottom: 16 },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 13 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  status: { fontSize: 11, fontWeight: '700' },
  heroTitle: { fontSize: 35, lineHeight: 39, fontWeight: '700', letterSpacing: -1.2, maxWidth: 340 },
  subtitle: { fontSize: 14, marginTop: 12, lineHeight: 20 },
  card: { marginHorizontal: 16, borderRadius: 22, borderWidth: 1, padding: 18, marginBottom: 16 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 },
  cardKicker: { fontSize: 10, fontWeight: '800', letterSpacing: 1.2, marginBottom: 7 },
  cardTitle: { fontSize: 23, fontWeight: '700', letterSpacing: -0.5 },
  iconCircle: { width: 42, height: 42, borderRadius: 21, justifyContent: 'center', alignItems: 'center' },
  uploadBox: { borderWidth: 1, borderStyle: 'dashed', borderRadius: 17, paddingVertical: 25, paddingHorizontal: 12, alignItems: 'center' },
  uploadIcon: { width: 52, height: 52, borderRadius: 26, justifyContent: 'center', alignItems: 'center', marginBottom: 11 },
  uploadTitle: { fontSize: 16, fontWeight: '700' },
  uploadHint: { fontSize: 12, marginTop: 5, marginBottom: 16 },
  buttonRow: { gap: 9, width: '100%' },
  primaryButton: { borderRadius: 12, minHeight: 47, paddingHorizontal: 15, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8 },
  primaryButtonText: { color: '#fffdf8', fontSize: 14, fontWeight: '800' },
  secondaryButton: { borderRadius: 12, minHeight: 42, paddingHorizontal: 15, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8, borderWidth: 1 },
  secondaryButtonText: { fontSize: 13, fontWeight: '700' },
  photo: { width: '100%', height: 210, borderRadius: 16, marginBottom: 12, backgroundColor: '#d8dfd0' },
  resultCard: { marginHorizontal: 16, borderRadius: 22, padding: 20, marginBottom: 22 },
  resultKicker: { color: '#e9c75a', fontSize: 10, fontWeight: '800', letterSpacing: 1.2, marginBottom: 10 },
  resultTitle: { color: '#fffdf8', fontSize: 24, lineHeight: 28, fontWeight: '700', letterSpacing: -0.5 },
  resultBody: { color: '#d6e0d5', fontSize: 14, lineHeight: 21, marginTop: 11 },
  resultNote: { flexDirection: 'row', alignItems: 'center', gap: 7, marginTop: 18 },
  resultNoteText: { color: '#e9c75a', fontSize: 11, flex: 1 },
  sectionHeading: { marginHorizontal: 20, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 10 },
  sectionTitle: { fontSize: 23, fontWeight: '700', letterSpacing: -0.5 },
  priceCard: { marginHorizontal: 16, borderRadius: 18, borderWidth: 1, padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  cropName: { fontSize: 16, fontWeight: '700' },
  priceLabel: { fontSize: 12, marginTop: 4 },
  priceRight: { alignItems: 'flex-end' },
  price: { fontSize: 22, fontWeight: '800' },
  up: { color: '#3f765d', fontSize: 12, fontWeight: '800', marginTop: 3 },
  alertCard: { marginHorizontal: 16, borderRadius: 18, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 11 },
  alertIcon: { width: 38, height: 38, borderRadius: 13, justifyContent: 'center', alignItems: 'center' },
  alertCopy: { flex: 1 },
  alertTitle: { fontSize: 14, fontWeight: '800' },
  alertSub: { fontSize: 11, marginTop: 3 },
  disclaimer: { marginHorizontal: 20, fontSize: 11, lineHeight: 16, marginTop: 20 },
});
