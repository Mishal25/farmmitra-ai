/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#24483b',
    tint: '#3f765d',

    // Core surfaces
    background: '#f7f2e8',
    foreground: '#24483b',

    // Cards / elevated surfaces
    card: '#fffdf8',
    cardForeground: '#24483b',

    // Primary action color (buttons, links, active states)
    primary: '#b94f2d',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#e6eadb',
    secondaryForeground: '#315a48',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#ece6d9',
    mutedForeground: '#6f786c',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#e9c75a',
    accentForeground: '#24483b',

    // Destructive actions (delete, error states)
    destructive: '#ef4444',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#dcd7ca',
    input: '#dcd7ca',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 14,
};

export default colors;
